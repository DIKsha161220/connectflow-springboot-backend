# ConnectFlow CRM — Complete Project & Installation Guide
**Prepared for Project Submission & Demonstration**

---

## 📌 Executive Summary (कामाचा सारांश)

Sir च्या सर्व आवश्यकतांनुसार (All requirements) खालील सर्व कामे यशस्वीरित्या पूर्ण झाली आहेत:

1. **User Registration & Account Creation (नवीन युजर्स खाते तयार करू शकतात)**:
   - `[Sign In]` सोबत `[Create Account]` चा नवीन टॅब जोडण्यात आला आहे.
   - वापरकर्ता आपले Full Name, Email, Password, Phone Number आणि Role (`Calling Team`, `On-field Employee`, `Administrative`) निवडून नवीन खाते तयार करू शकतो.
   - Spring Boot बॅकएंड आणि स्थानिक सुरक्षित स्टोरेज दोन्हीमध्ये रजिस्ट्रेशन व्यवस्था कार्यान्वित केली आहे.

2. **Data Persistence (डेटा कायम सेव्ह राहतो - उद्याही आणि रिफ्रेश केल्यावरही)**:
   - Institute, Call Logs, Visits आणि Follow-ups चा डेटा Browser Storage आणि Backend Database (PostgreSQL) मध्ये सुरक्षित सेव्ह होतो.
   - Logout केल्यावर किंवा Browser बंद करून पुन्हा उघडल्यावर डेटा नष्ट होत नाही (No data loss).
   - `localStorage` आणि Local Live DB sync मुळे सर्व रेकॉर्ड्स जतन राहतात.

3. **Full Screen Responsive Dashboard (डॅशबोर्ड पूर्ण स्क्रीनवर दिसेल)**:
   - डाव्या व उजव्या बाजूला दिसणारी अनावश्यक पांढरी जागा (whitespace) काढून डॅशबोर्डला 100% full-width रिस्पॉन्सिव्ह डिझाईन देण्यात आले आहे.
   - Sidebar, Topbar, Metrics आणि Tables आता प्रत्येक स्क्रीनवर सुबकपणे पसरून दिसतात.

4. **Desktop App & Android APK Ready Package**:
   - संगणकावर (Windows PC) चालवण्यासाठी 1-Click `.bat` लाँचर आणि Chrome/Edge Desktop App (PWA) इन्स्टॉल करता येते.
   - मोबाईलसाठी संपूर्ण **Android Studio Project** तयार करून देण्यात आला आहे ज्यातून 1 मिनिटात **Android APK** जनरेट करता येतो.

---

## 💻 1. संगणकावर (PC) कसे चालवायचे / कसे इन्स्टॉल करायचे?

### पर्याय A: 1-Click द्वारे थेट सुरू करा
1. या फोल्डरमधील `ConnectFlow-CRM.bat` फाईलवर **Double Click** करा.
2. ConnectFlow CRM त्वरित तुमच्या स्क्रीनवर उघडेल.

### पर्याय B: Desktop App म्हणून इन्स्टॉल करा (PWA)
1. `index.html` फाईल Google Chrome किंवा Microsoft Edge मध्ये उघडा.
2. Address Bar च्या उजव्या बाजूला दिसणाऱ्या **"Install ConnectFlow CRM"** (किंवा Desktop आयकॉन) वर क्लिक करा.
3. आता तुमच्या डेस्कटॉपवर **ConnectFlow CRM चा स्वतंत्र App आयकॉन** तयार होईल!

---

## 📱 2. मोबाईलसाठी Android APK कसा तयार करायचा? (Android Studio द्वारे)

या पॅकेजमधील `android` फोल्डर हे संपूर्ण Android Studio प्रोजेक्ट आहे:

1. **Android Studio** सॉफ्टवेअर उघडा.
2. **Open Project** वर क्लिक करा आणि हे फोल्डर निवडा:
   `D:\CRM-BACKEND12\ConnectFlow-CRM-Build-Package\android`
3. Gradle Sync पूर्ण होईपर्यंत थांबा (10-20 सेकंद).
4. वरच्या मेन्यूमध्ये:
   **Build** ➡️ **Build Bundle(s) / APK(s)** ➡️ **Build APK(s)** वर क्लिक करा.
5. Android Studio खाली उजव्या कोपऱ्यात **"locate"** अशी लिंक दाखवेल:
   त्यावर क्लिक करा, तुम्हाला तुमचा `app-debug.apk` मिळेल!
6. हा APK कोणत्याही Android फोनमध्ये पाठवून थेट इन्स्टॉल करा.

---

## 🔑 3. Default Login Credentials (चाचणीसाठी खाती)

| भूमिका (Role) | Email | Password |
|---|---|---|
| **Administrative** | `amit.patil@example.com` | `root` |
| **Calling Team** | `sneha.deshmukh@example.com` | `root` |
| **नवीन तयार केलेले खाते** | वापरकर्त्याने भरलेला Email | वापरकर्त्याने भरलेला Password |

---

## 📁 पॅकेजची फाईल रचना (File Structure)

```text
ConnectFlow-CRM-Build-Package/
├── ConnectFlow-CRM.bat     (Windows 1-Click Desktop Launcher)
├── index.html              (Standalone CRM Frontend Application)
├── manifest.json           (PWA Configuration for Desktop/Mobile Installation)
├── sw.js                   (Offline Service Worker)
├── README-FOR-SIR.md       (हा संपूर्ण माहितीचा दस्तऐवज)
├── HOW-TO-RUN.txt          (Quick run instructions)
├── connectflow/
│   ├── app.js              (CRM Application Logic, Storage & Sync)
│   └── style.css           (100% Full-Width Responsive Stylesheet)
└── android/                (Complete Android Studio Project for APK build)
    ├── build.gradle
    ├── settings.gradle
    └── app/
        ├── build.gradle
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/connectflow/crm/MainActivity.java
            └── assets/public/  (Embedded offline web assets)
```
